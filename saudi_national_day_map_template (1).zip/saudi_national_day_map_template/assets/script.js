
// === تهيئة الخريطة ===
const map = L.map('map', {
  center: [23.8859, 45.0792], // مركز السعودية
  zoom: 5,
  zoomControl: true,
});

// طبقة البلاط (خرائط مفتوحة المصدر)
const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
});
tiles.addTo(map);

// === مثال: نقاط/فعاليات ===
const places = [
  {
    name: 'أبها – مسرح الفعالية',
    coords: [18.2164, 42.5053],
    desc: 'عرض مسرحي خاص باليوم الوطني 95 – الساعة 7:30 مساءً',
  },
  {
    name: 'الرياض – ساحة الاحتفال',
    coords: [24.7136, 46.6753],
    desc: 'ألعاب نارية وعروض جوية',
  },
];

const detailsEl = document.getElementById('details');

places.forEach((p) => {
  const marker = L.marker(p.coords).addTo(map);
  marker.bindPopup(`<strong>${p.name}</strong><br/>${p.desc}`);
  marker.on('click', () => {
    detailsEl.innerHTML = `<div class="card"><h3 style="margin:.2rem 0 .4rem">${p.name}</h3><p style="margin:0">${p.desc}</p></div>`;
  });
});

// === كيفية دمج شيفرتك الحالية ===
// إذا كان لديك ملف HTML جاهز (خريطة_اليوم_الوطني95_نسخة_المسرح.html)
// يمكنك ببساطة فتحه ونسخ الشيفرة الخاصة بالخريطة (الـ <script> و CSS)
// ولصقها هنا بدلاً من الكود أعلاه، أو استبدال هذا الملف بالكامل بملفك وتسميته index.html.
